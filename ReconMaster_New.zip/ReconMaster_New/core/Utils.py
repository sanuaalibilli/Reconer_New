from _datetime import datetime
import configparser
import os.path
import glob
import gzip
import shutil
import pandas as pd



def getNowDate():
    return (datetime.now().strftime('%Y%m%d_%H%M%S'))

def getPostDate(daysfuture):
    return (datetime.now())

def getConfigProperty(section_name, key_name):    
    config = configparser.RawConfigParser()
    config.read('config.properties')
    #print("CONFIG PROPERTY: "+section_name+" : "+key_name+" : "+config.get(section_name,key_name))
    return config.get(section_name,key_name)

def getInputFiles(filePath):
    infile=open(filePath,'r')
    return infile.readlines()

def getKeyColumnValues(data,keycolumnIndices):
    values = ""
    
    if("," in str(keycolumnIndices)):
        print(keycolumnIndices.split(","))       
        for word in keycolumnIndices.split(","):
            values = values + "," + (data[int(word)-1]).split("|")[1]
    else:
        values = (data[keycolumnIndices-1]).split("|")[1]
    return str(values).strip(",")    

def parseFileLinks(fileLinks,busDate,busDateParam):
    parsedLinks = []
    for link in fileLinks :
        parsedLinks.append(link.strip().replace(busDateParam,busDate))
    return parsedLinks

def parseFileLink(fileLink,busDate,busDateParam):
    return (fileLink.strip().replace(busDateParam,busDate))     

def setAliases(aliases,out_row):
    temp = out_row
    for index, row in pd.DataFrame(aliases).iterrows():
        if row['ColumnName'] in temp:
            #print(row['ColumnName'],row['Alias'])
            temp=temp.replace(row['ColumnName'],row['Alias'])
    return temp
  
def mapColumnandRow(columns,row):
    mappedLines = []
    columnz=columns.split("|")
    counter = 0
    for li in row.split("|"):
        #print(columnz[counter] + "|" + li.strip())
        mappedLines.append(columnz[counter] + "|" + li.strip())
        counter = counter + 1
    return mappedLines

def iskeyColumn(keycolumnNames,data):
    status = False
    for colName in keycolumnNames.split(","):
        if colName in data:
            status = True
            break
    return status


def gzipOldFiles(dirPath):
    files = glob.glob(os.path.join(dirPath+"*.dat"))
    print(files)
    filecount = len(files) 
    print(filecount, " Old Files Present in Output Directory")
    if (len(files) > 0):
        for f in files:
            with open(f, 'rb') as f_in, gzip.open(f+".gz", 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
            f_in.close()
            f_out.close()
            print("Deleting File : "+f)
            os.remove(f)