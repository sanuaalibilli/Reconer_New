import pandas as pd
from core.Utils import *



#Get Excel File:
#Pre-requisite 
#install pandas by running "pip install pandas"
#install xlrd by running "pip install xlrd"

excelFile = getConfigProperty("INPUTS","MAPPINGS_ALIASES_FILE")
mappings = pd.read_excel(excelFile,sheet_name="Mappings")
aliases = pd.read_excel(excelFile,sheet_name="Aliases")
#filenames = pd.DataFrame(mappings, columns= ['FileName'])
fileNameIndex = mappings.columns.get_loc("FileName")
dataSetIndex = mappings.columns.get_loc("DataSetName")
keyColNamesIndex = mappings.columns.get_loc("KeyColumnNames")
keyColIndicesIndex = mappings.columns.get_loc("KeyColumnIndices")

alias_Mapper = getConfigProperty("INPUTS","SET_ALIAS")

headerOn = "False"
#print(fileNameIndex)
for row in mappings.itertuples(): 
    fileName = (row[fileNameIndex+1])
    dataSetName = (row[dataSetIndex+1])
    keycolumnNames = (row[keyColNamesIndex+1])
    keycolumnIndices = (row[keyColIndicesIndex+1])
    
    actualFileName = parseFileLink(fileName, getConfigProperty("INPUTS","BUSINESS_DATE"), getConfigProperty("INPUTS","BUSINESS_DATE_PARAM"))
    
    print("PROCESSING FILE : " + actualFileName)
    #CHECK IF FILE EXISTS AND OPEN IT FOR PROCESING
    if not (os.path.exists(actualFileName)):
        print("File Doesnot Exist : " + actualFileName )
        continue
    ##################################################
    
    openInputFile = open(actualFileName,'r')
    
    outFileType = getConfigProperty("INPUTS","OUTPUT_FILE_TYPE")
    outFileDir = getConfigProperty("INPUTS","OUTPUT_DIRECTORY")
    outFileName=""
    if("SINGLE" == outFileType.strip()):
        outFileName = os.path.join((outFileDir),(parseFileLink(getConfigProperty("INPUTS","SINGLE_OUTFILE_NAME"),getConfigProperty("INPUTS","BUSINESS_DATE"), getConfigProperty("INPUTS","BUSINESS_DATE_PARAM"))))
        #headerOn = True
    else:
        path, name = os.path.split(actualFileName)
        outFileNm = getConfigProperty("INPUTS","OUTPUT_FILE_PREFIX")+"_"+name.strip()
        outFileName=os.path.join(outFileDir,outFileNm)
    print("Using Ouput File : " + outFileName)
    #CREATE OUTPUTFILE DIRECTORY STRUCTURE IF NOT PRESENT
    if not (os.path.exists(outFileDir)):
        print("Output Directory Does not Exist : " + outFileDir )
        print("Creating Output Directory : " + outFileDir )
        os.makedirs(outFileDir)
    #OPEN OUT FILE
    openOutfile = open(outFileName,"a")
    
    #to write header to output file
    if(("SINGLE" == outFileType.strip())):
        if (headerOn == "False"):
            print("Header is not Written. So Writing")
            openOutfile.write(getConfigProperty("INPUTS","OUTPUT_FILE_HEADER")+"\n")
            headerOn = "True"
        else:
            print("Header is Written. So Skipping")
    else:
        openOutfile.write(getConfigProperty("INPUTS","OUTPUT_FILE_HEADER")+"\n")
    
    i = 0
    coulmns = "" #variable to store the column names
    while True:
        i = i+1
        line = openInputFile.readline()
        strLine = line.strip()
        #print("Line# is ",i," : Line is ",str)
        #BREAK THE LOOP ON END OF FILE
        if not line: 
            break
        
        #SKIPPING HEADER LINE IN FILE
        if strLine.startswith("HDR"):
            continue    
        
        #SKIPPING FOOTER LINE IN FILE
        if strLine.startswith("TRL"):
            continue   
        
        #this line is the column names from the input file
        if (i == 2):
            columns = line.strip() 
            print(columns)
        else:
            businessDate = getConfigProperty("INPUTS","BUSINESS_DATE")
            #column1|data, column2|data
            mappedLine = mapColumnandRow(columns,line)
            keyColumnValues = getKeyColumnValues(mappedLine, keycolumnIndices)
            for data in mappedLine:
                if not("record_type" in data):
                    if not(iskeyColumn(keycolumnNames,data)):
                        out_row = businessDate +"|"+ dataSetName + "|" + keycolumnNames +"|"+ keyColumnValues + "|" +  data
                
                        if("True" == alias_Mapper):
                            temp = setAliases(aliases,out_row)
                            out_row = temp
                        openOutfile.write((out_row.strip())+ "\n")
        
               
    
    openOutfile.close()
    openInputFile.close()
    


